import mysql.connector
from ibookdb import IBOOKDB
from queryresult import QueryResult
from author import Author
from book import Book
from author_of import Author_of
from publisher import Publisher
from typing import List

class BOOKDB(IBOOKDB):

    def __init__(self,user,password,host,database,port):
        self.user = user
        self.password = password
        self.host = host
        self.database = database
        self.port = port
        self.connection = None

    def initialize(self):
        self.connection = mysql.connector.connect(
            user=self.user,
            password=self.password,
            host=self.host,
            database=self.database,
            port=self.port
        )

    def disconnect(self):
        if self.connection is not None:
            self.connection.close()


    def createTables(self):
        if not self.connection:
            return "Bağlantı yok. Önce bağlantıyı başlatın."

        mycursor = self.connection.cursor()
        # Author table
        author_table = "CREATE TABLE IF NOT EXISTS author (author_id INT PRIMARY KEY, author_name VARCHAR(60))"
        
        # Publisher table
        publisher_table = "CREATE TABLE IF NOT EXISTS publisher (publisher_id INT PRIMARY KEY, publisher_name VARCHAR(50))"

        # Book table with foreign key to publisher
        book_table = "CREATE TABLE IF NOT EXISTS book (isbn CHAR(13) PRIMARY KEY, book_name VARCHAR(120), publisher_id INT, FOREIGN KEY(publisher_id) REFERENCES publisher(publisher_id), first_publish_year CHAR(4), page_count INT, category VARCHAR(25), rating FLOAT)"

        # Author_of table with foreign keys to book and author
        author_of_table = "CREATE TABLE IF NOT EXISTS author_of (isbn CHAR(13), author_id INT, PRIMARY KEY (isbn, author_id), FOREIGN KEY (isbn) REFERENCES book(isbn), FOREIGN KEY (author_id) REFERENCES author(author_id))"
        # PHW1 table
        phw1_table = "CREATE TABLE IF NOT EXISTS phw1 (isbn CHAR(13) PRIMARY KEY, book_name VARCHAR(120), rating FLOAT)"


        mycursor.execute(author_table)
        mycursor.execute(publisher_table)
        mycursor.execute(book_table)
        mycursor.execute(author_of_table)
        mycursor.execute(phw1_table)

        mycursor.execute("Show tables;")

        numberOfTables = mycursor.fetchall()
        """
        for tables in cursor:
        print(tables)
        """

        return len(numberOfTables)


    def dropTables(self):
        pass


    def insertAuthor(self,authors):
        if not self.connection:
            return 0
        
        mycursor = self.connection.cursor()
        
        inserted_rows = 0
        for author in authors:
            sql = "INSERT INTO author (author_id, author_name) VALUES (%s, %s)"
            val = (author.author_id, author.author_name)
            mycursor.execute(sql, val)
            inserted_rows += mycursor.rowcount

        self.connection.commit()  # Değişiklikleri kaydet
        return inserted_rows
      
    def insertBook(self,books):
        if not self.connection:
            return 0
        
        mycursor = self.connection.cursor()

        inserted_rows = 0
        for book in books:
            sql = "INSERT INTO book (isbn, book_name, publisher_id, first_publish_year, page_count, category, rating) VALUES (%s, %s, %s,%s, %s, %s, %s)"
            val = (book.isbn, book.book_name, book.publisher_id, book.first_publish_year, book.page_count, book.category, book.rating)
            mycursor.execute(sql, val)
            inserted_rows += mycursor.rowcount

        self.connection.commit()
        return inserted_rows
        

    def insertPublisher(self,publishers):
        if not self.connection:
            return 0
        
        mycursor = self.connection.cursor()

        inserted_rows = 0
        for publisher in publishers:
            sql = "INSERT INTO publisher (publisher_id, publisher_name) VALUES (%s, %s)"
            val = (publisher.publisher_id, publisher.publisher_name)
            mycursor.execute(sql, val)
            inserted_rows += mycursor.rowcount
                    
        self.connection.commit()
        return inserted_rows
    

    def insertAuthor_of(self,author_ofs):
        if not self.connection:
            return 0
        
        mycursor = self.connection.cursor()

        inserted_rows = 0
        for author_of in author_ofs:
            sql = "INSERT INTO author_of (author_id, isbn) VALUES (%s, %s)"
            val = (author_of.author_id, author_of.isbn)
            mycursor.execute(sql, val)
            inserted_rows += mycursor.rowcount

        self.connection.commit()
        return inserted_rows


    def functionQ1(self):
        try:
            if not self.connection:
                print("Veritabanı bağlantısı bulunamadı.")
                return []

            mycursor = self.connection.cursor()

            # En fazla sayfaya sahip kitap(lar) için sorgu
            sqlCommand = """
                SELECT b.isbn, b.first_publish_year, b.page_count, p.publisher_name
                FROM book b
                JOIN publisher p ON b.publisher_id = p.publisher_id
                WHERE b.page_count = (SELECT MAX(page_count) FROM book)
                ORDER BY b.isbn ASC
            """

            mycursor.execute(sqlCommand)

            results = []
            for (isbn, first_publish_year, page_count, publisher_name) in mycursor.fetchall():
                result = QueryResult.ResultQ1(
                    isbn=isbn,
                    first_publish_year=first_publish_year,
                    page_count=page_count,
                    publisher_name=publisher_name
                )
                results.append(result)

            return results
        
        except Exception as e:
            print("Hata:", e)
            return []

    def functionQ2(self,author_id1, author_id2):
        try:
            if not self.connection:
                print("Veritabanı bağlantısı bulunamadı.")
                return []

            mycursor = self.connection.cursor()

            # Basit bir sorgu örneği: Yayınevlerini ve yayımladıkları kitap sayısını listele
            sqlCommand = """
            SELECT p.publisher_id, p.publisher_name, COUNT(b.isbn) AS book_count
            FROM publisher p
            JOIN book b ON p.publisher_id = b.publisher_id
            GROUP BY p.publisher_id, p.publisher_name
            ORDER BY p.publisher_id ASC;
            """

            mycursor.execute(sqlCommand)

            results = []
            for (publisher_id, publisher_name, book_count) in mycursor.fetchall():
                result = QueryResult.ResultQ2(
                    publisher_id = publisher_id,
                    publisher_name = publisher_name,
                    book_count = book_count
                )
                results.append(result)

            return results

        except Exception as e:
            print("Hata:", e)
            return []

    def functionQ3(self,author_name):
        try:
            if not self.connection:
                print("Veritabanı bağlantısı bulunamadı.")
                return []

            mycursor = self.connection.cursor()

            # SQL sorgusu
            sqlCommand = """
            SELECT b.book_name, b.category, b.first_publish_year
            FROM author a
            JOIN author_of ao ON a.author_id = ao.author_id
            JOIN book b ON ao.isbn = b.isbn
            WHERE a.author_name = ?
            ORDER BY b.book_name ASC, b.category ASC, b.first_publish_year ASC;
            """

            # Parametreler
            params = (author_name,)

            # Sorguyu çalıştır
            mycursor.execute(sqlCommand, params)

            results = []
            for (book_name, category, first_publish_year) in mycursor.fetchall():
                result = QueryResult.ResultQ3(
                    book_name = book_name,
                    category = category,
                    first_publish_year = first_publish_year
                )
                results.append(result)

            return results

        except Exception as e:
            print("Hata:", e)
            return []



    def functionQ4(self):
        mycursor = self.connection.cursor()
        
        # SQL sorgusu
        sql_query = """
            SELECT 
                p.publisher_id,
                b.category
            FROM 
                publisher p
            JOIN 
                book b ON p.publisher_id = b.publisher_id
            WHERE 
                LENGTH(p.publisher_name) - LENGTH(REPLACE(p.publisher_name, ' ', '')) >= 2
                AND p.publisher_id IN (
                    SELECT 
                        publisher_id
                    FROM 
                        book
                    GROUP BY 
                        publisher_id
                    HAVING 
                        COUNT(DISTINCT isbn) >= 3
                        AND AVG(rating) > 3
                )
            GROUP BY 
                p.publisher_id,
                b.category
            ORDER BY 
                p.publisher_id,
                b.category;
        """

        # SQL sorgusunu çalıştır
        mycursor.execute(sql_query)
        results = []
        for (publisher_id, category) in mycursor.fetchall():
            result = QueryResult.ResultQ4(
                publisher_id=publisher_id,
                category=category
            )
            results.append(result)

        # Sonuçları döndür
        return results
    
    def functionQ5(self,author_id):
        pass
    def functionQ6(self):
        pass
    def functionQ7(self,rating):
        pass
    def functionQ8(self):
        pass
    def functionQ9(self,keyword):
        pass
    def function10(self):
        pass
